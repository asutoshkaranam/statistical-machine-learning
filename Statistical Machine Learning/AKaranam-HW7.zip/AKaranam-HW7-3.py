#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt

def get_data_x_y(n):
    _f = lambda x: 4 * np.cos(4 * np.pi * x) * np.log(x**2 + 1)
    _x = np.random.uniform(low=0, high=1, size=(n, ))
    error_std_normal = np.random.normal(size=(n, ))
    _y = _f(_x) + error_std_normal
    return (_x,_y)


# In[2]:


def get_K_matrx(kernel_function, x, n):
    return np.fromfunction(lambda i, j: kernel_function(x[i], x[j]), shape=(n,n), dtype=int)


def kernel_ridge_regress_func(x, y, kern_func, lambdaa, n):
    Kern_f = get_K_matrx(kernel_function=kern_func, x=x, n=n)

    alfa_dash = np.linalg.solve(Kern_f + lambdaa * np.eye(n), y)

    _f = lambda z: np.sum(np.dot(alfa_dash, kern_func(z, x)))
    return _f

def leave_out_one_tuner(x, y, kernel_function, lambda_arr, hyper_param_arr, n):
    err_mtrx = np.empty((len(lambda_arr), len(hyper_param_arr)))
    for row, lambdaa in enumerate(lambda_arr):
        for col, hyper_param in enumerate(hyper_param_arr):
            accumulated_loo_err = 0
            for j in range(n):
                x_test = x[j]
                y_test = y[j]
                x_training = np.concatenate((x[:j], x[j+1:]))
                y_training = np.concatenate((y[:j], y[j+1:]))

                kern_func = lambda x, x_dash: kernel_function(x, x_dash, hyper_param)
                f = kernel_ridge_regress_func(x=x_training, y=y_training, kern_func=kern_func, lambdaa=lambdaa, n=n-1)

                accumulated_loo_err += (y_test - f(x_test)) ** 2

            accumulated_loo_err = accumulated_loo_err / n
            err_mtrx[row, col] = accumulated_loo_err

    index_lambdaa_arr, hyperparam_arr_index = np.unravel_index(np.argmin(err_mtrx, axis=None), err_mtrx.shape)
    return (lambda_arr[index_lambdaa_arr], hyper_param_arr[hyperparam_arr_index])

def plot_second(x,y, kern_func, lambdaa, hyper_param, n, kernel_id):
    plt.figure()
    true_f_x = lambda x: 4 * np.cos(4 * np.pi * x) * np.log(x**2 + 1)

    x_predict, kernel_y = get_f_dash(x=x,y=y,kern_func=kern_func,hyper_param=hyper_param, lambdaa=lambdaa, n=n)
    plt.plot(x, y, 'ko')
    plt.plot(x_predict, true_f_x(x_predict))

    plt.plot(x_predict, kernel_y)
    plt.legend(['Generated Data', 'True f_x', 'Kernel Ridge Regression'])
    plt.ylabel('y')
    plt.xlabel('x')
    plt.title('Kernel Ridge Regression (' + kernel_id + ')')
    plt.show()

def get_f_dash(x,y,kern_func, hyper_param, lambdaa, n, dataset_size=1000):
    f_dash = kernel_ridge_regress_func(x=x,y=y, lambdaa=lambdaa, kern_func=lambda x, x_dash: kern_func(x, x_dash, hyper_param), n=n)

    x_predict = np.linspace(0,1, dataset_size)
    kernel_y = [f_dash(x_i) for x_i in x_predict]
    return x_predict, kernel_y


# In[3]:


#1) Polynomial Kernel
n = 30
x, y = get_data_x_y(n)

lambda_arr = [10**k for k in np.linspace(-6, 1, 25)]
d_arr = list(range(1, 20, 1))
kernel_func_lambda = lambda x, x_dash, d: np.power((1 + x * x_dash), d)
optimum_lambda, optimum_d = leave_out_one_tuner(x=x, y=y, kernel_function=kernel_func_lambda, lambda_arr=lambda_arr, hyper_param_arr=d_arr, n=n)

print("Kernel Function -- Polynomial\n")
print("Optimum lambda value : ", optimum_lambda, " Optimum d: ", optimum_d)

plot_second(x=x, y=y, kern_func=kernel_func_lambda, lambdaa=optimum_lambda, hyper_param=optimum_d, n=n, kernel_id='Poly')

# 2) RBF Kernel
estimate_gamma = 1 / np.median([(x[i] - x[j]) ** 2 for i in range(n) for j in range(n)])
print('gamma estimated : ', estimate_gamma)

gamma_arr = np.linspace(1, 25, 20)
kernel_func_rbf = lambda x, x_dash, gamma: np.exp(-gamma * np.power(x - x_dash, 2))
optimum_lambda, optimum_gamma = leave_out_one_tuner(x=x, y=y, kernel_function=kernel_func_rbf, lambda_arr=lambda_arr, hyper_param_arr=gamma_arr, n=n)

print("\n\n Kernel Function -- RBF \n")
print("Optimum lambda: ", optimum_lambda, " Optimum gamma: ", optimum_gamma)

plot_second(x=x, y=y, kern_func=kernel_func_rbf, lambdaa=optimum_lambda, hyper_param=optimum_gamma, n=n, kernel_id='RBF')


# In[ ]:




