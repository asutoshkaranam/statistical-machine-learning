#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_val_score
import warnings
warnings.filterwarnings('ignore')

# Set reproducibility seeding
np.random.seed(1234)

# Initialize the Different parameters
mean_class1_1 = np.array([-1/4, 1])
mean_class1_2 = np.array([-1/2, 1/2])
mean_class_minus1_1 = np.array([1/4, 1])
mean_class_minus1_2 = np.array([0, 1/2])

std_class1_1 = np.array([[0.015, 0], [0, 0.005]])
std_class1_2 = np.array([[0.05, 0], [0, 0.005]])
std_class_minus1_1 = std_class1_1
std_class_minus1_2 = std_class1_2

# data generation function for classes 1 and -1
def data_generator_fxn(num_samples_each_group):
    num_samples = num_samples_each_group * 2
    X1_class1_1 = np.random.multivariate_normal(mean_class1_1, std_class1_1, num_samples_each_group)
    X1_class1_2 = np.random.multivariate_normal(mean_class1_2, std_class1_2, num_samples_each_group)
    X1 = np.vstack((X1_class1_1, X1_class1_2))
    y1 = np.ones(num_samples)
    
    X1_class_minus1_1 = np.random.multivariate_normal(mean_class_minus1_1, std_class_minus1_1, num_samples_each_group)
    X1_class_minus1_2 = np.random.multivariate_normal(mean_class_minus1_2, std_class_minus1_2, num_samples_each_group)
    X_minus1 = np.vstack((X1_class_minus1_1, X1_class_minus1_2))
    y_minus1 = -np.ones(num_samples)
    
    # Merge both the class's data
    X = np.vstack((X1, X_minus1))
    y = np.hstack((y1, y_minus1))
    
    return X, y

#Compute The Likelihood of the classes -1 and 1
def decision_function_bayes(X):
    pdf_class1_1 = multivariate_normal.pdf(X, mean=mean_class1_1, cov=std_class1_1)
    pdf_class1_2 = multivariate_normal.pdf(X, mean=mean_class1_2, cov=std_class1_2)
    p_x_given_1 = 0.5 * pdf_class1_1 + 0.5 * pdf_class1_2
    
    pdf_class_minus1_1 = multivariate_normal.pdf(X, mean=mean_class_minus1_1, cov=std_class_minus1_1)
    pdf_class_minus1_2 = multivariate_normal.pdf(X, mean=mean_class_minus1_2, cov=std_class_minus1_2)
    p_x_given_minus1 = 0.5 * pdf_class_minus1_1 + 0.5 * pdf_class_minus1_2
    
    # Return the generated decision values
    return p_x_given_1 - p_x_given_minus1

# Construct the mesh grid for plotting the decision function
def decision_boundary_plotter_fxn(X, y, classifier=None):
    x_min, x_max = X[:, 0].min() - 0.5, X[:, 0].max() + 0.5
    y_min, y_max = X[:, 1].min() - 0.5, X[:, 1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 100),
                        np.linspace(y_min, y_max, 100))
    mesh_points = np.c_[xx.ravel(), yy.ravel()]
    
    plt.figure(figsize=(10, 8))
    
    # Plot the scatter plot of training data
    plt.scatter(X[y == 1][:, 0], X[y == 1][:, 1], c='blue', alpha=0.5, label='Class 1')
    plt.scatter(X[y == -1][:, 0], X[y == -1][:, 1], c='red', alpha=0.5, label='Class -1')
    
    # Plot Bayes decision boundary
    predict_bayes = decision_function_bayes(mesh_points)
    predict_bayes = predict_bayes.reshape(xx.shape)
    plt.contour(xx, yy, predict_bayes, levels=[0], colors='green', label='Bayes Boundary')
    
    # Plot classifier decision boundary in case of KNN along with bayes decision boundary
    if classifier is not None:
        predict_knn = classifier.predict(mesh_points)
        predict_knn = predict_knn.reshape(xx.shape)
        plt.contour(xx, yy, predict_knn, levels=[0], colors='purple', label='KNN Boundary')
    
    plt.legend()
    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.title('Decision Boundaries and Scatter Plot of Data Points')
    plt.show()

def bayes_error_compute_fxn(X_test, y_test):
    predictions = np.sign(decision_function_bayes(X_test))
    return np.mean(predictions != y_test)

# Generate training and test data
X_train, y_train = data_generator_fxn(2000)
X_test, y_test = data_generator_fxn(1000)

# Plot the decision boundary - initial
decision_boundary_plotter_fxn(X_train, y_train)

# Perform the k-NearestNeighbor analysis
k_values = range(1, 31)
train_error_arr = []
cross_validation_error_arr = []
cross_validation_std_arr = []
test_error_arr = []
bayes_error_arr = []

bayes_error = bayes_error_compute_fxn(X_test, y_test)
bayes_error_arr = [bayes_error] * len(k_values)

for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    
    # Compute Training error
    train_pred = knn.predict(X_train)
    train_error_arr.append(np.mean(train_pred != y_train))
    
    # Compute CV error
    cv_scores = cross_val_score(knn, X_train, y_train, cv=10)
    cross_validation_error_arr.append(np.mean(1 - cv_scores))
    cross_validation_std_arr.append(np.std(1 - cv_scores)/ np.sqrt(10))
    
    # Compute Test error
    test_pred = knn.predict(X_test)
    test_error_arr.append(np.mean(test_pred != y_test))

plt.figure(figsize=(12, 8))
plt.errorbar(k_values, cross_validation_error_arr, 
             yerr=cross_validation_std_arr, 
             fmt='g-', 
             capsize=5, 
             label='CV Error')
plt.plot(k_values, train_error_arr, 'b-', label='Training Error')
plt.plot(k_values, test_error_arr, 'r-', label='Test Error')
plt.plot(k_values, bayes_error_arr, 'k--', label='Bayes Error')
plt.xlabel('k')
plt.ylabel('Error Rate')
plt.title('Error Rates vs k')
plt.legend()
plt.grid(True)
plt.show()

# Choose the optimal k value based on Cross Validation error
optimal_k = k_values[np.argmin(cross_validation_error_arr)]
print("Optimal K : ", optimal_k)
optimal_knn = KNeighborsClassifier(n_neighbors=optimal_k)
optimal_knn.fit(X_train, y_train)

# Plot final comparison of boundaries
decision_boundary_plotter_fxn(X_train, y_train, optimal_knn)


# In[ ]:




