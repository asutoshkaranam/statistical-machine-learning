#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from scipy.stats import multivariate_normal

# Set reproducibility seeding
np.random.seed(42)

##Generate the mean vectors and covariance matrices for each of the classes
def gaussian_params_generator_fxn(num_classes=8):
    mean_arr = []
    covriance_arr = []
    
    # classes 1,2,3,4
    for i in range(1, 5):
        mean = np.array([
            np.random.uniform(-i, -i + 1),
            np.random.uniform(i - 1, i)
        ])
        cov = np.diag([
            np.random.uniform(0, 1/4),
            np.random.uniform(0, 1/4)
        ])
        mean_arr.append(mean)
        covriance_arr.append(cov)
    
    #classes 5,6,7,8
    for i in range(1, 5):
        mean = np.array([
            np.random.uniform(i - 1, i),
            np.random.uniform(i - 1, i)
        ])
        cov = np.diag([
            np.random.uniform(0, 1/4),
            np.random.uniform(0, 1/4)
        ])
        mean_arr.append(mean)
        covriance_arr.append(cov)
    
    return mean_arr, covriance_arr

## Generate and merge the the data points from the different Gaussian distributions
def generate_and_merge_data(mean_arr, covriance_arr, num_samples_each_class, num_classes=8):
    X = []
    y = []
    
    for class_idx in range(num_classes):
        temp_sample = np.random.multivariate_normal(
            mean=mean_arr[class_idx],
            cov=covriance_arr[class_idx],
            size=num_samples_each_class
        )
        X.append(temp_sample)
        y.append(np.full(num_samples_each_class, class_idx))
    
    return np.vstack(X), np.hstack(y)

mean_arr, covriance_arr = gaussian_params_generator_fxn()

# Generate the train and test sets
X_train, y_train = generate_and_merge_data(mean_arr, covriance_arr, num_samples_each_class=1000)
X_test, y_test = generate_and_merge_data(mean_arr, covriance_arr, num_samples_each_class=200)

# Plot the training data and run k-means algorithm with k value - 8
k = 8
kmeans_model = KMeans(n_clusters=k, n_init=10, random_state=42)
kmeans_model.fit(X_train)

# Plot the the scatter plot
plt.figure(figsize=(12, 8))
scatter = plt.scatter(X_train[:, 0], X_train[:, 1], c=y_train, cmap='tab10', alpha=0.6, label='Data points')
centers = plt.scatter(kmeans_model.cluster_centers_[:, 0], kmeans_model.cluster_centers_[:, 1], 
                     c='red', marker='*', s=200, label='Cluster centers')

plt.title('Mixture of Gaussian Data with K-means clusters=8')
plt.xlabel('X1')
plt.ylabel('X2')
plt.legend()
plt.colorbar(scatter, label='Class')
plt.grid(True)
plt.show()

# Run k-means algorithm for different values of k
k_values = range(1, 21)
train_error_arr = []
test_error_arr = []

for k in k_values:
    print(f"Running k-means algorithms with k={k}")
    kmeans_model = KMeans(n_clusters=k, n_init=10, random_state=42)
    kmeans_model.fit(X_train)
    
    # Compute the average inertia for each sample
    train_error = kmeans_model.inertia_ / len(X_train)
    train_error_arr.append(train_error)
    
    # Calculate test error
    test_error = kmeans_model.score(X_test) * (-1) / len(X_test)
    test_error_arr.append(test_error)

# Plot the training and test errors curves
plt.figure(figsize=(12, 6))
plt.plot(k_values, train_error_arr, label='Train Error', marker='o', color='blue')
plt.plot(k_values, test_error_arr, label='Test Error', marker='s', color='red')

y_min = min(min(train_error_arr), min(test_error_arr)) * 0.9
y_max = max(max(train_error_arr), max(test_error_arr)) * 1.1
plt.ylim(y_min, y_max) 
plt.yticks(np.linspace(y_min, y_max, 15))  

x_min = min(k_values) - 1  
x_max = max(k_values) + 1  
plt.xlim(x_min, x_max)  
plt.xticks(np.arange(x_min, x_max + 1, 1))  
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Average Objective Value')
plt.title('Training and Test Errors vs. k')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)  
plt.show()


# In[ ]:




