import numpy as np
import matplotlib.pyplot as plt

theta = 0.4
c = 4
n = np.arange(10, 310, 10)
m = 10000 #Choose big enough value

def get_samples(n, theta):
    probs = [theta, (1 - theta) / 2, (1 - theta) / 2]
    values = [3, 0, 6]
    return np.random.choice(values, size=(m, n), p=probs) #give the probabilities of choosing each value in probs

def markov(c):
    return (3 / c)

def chebyshev(n, c, theta):
    variance = 9 * (1 - theta)
    return (variance / (n * (c - 3) ** 2))

def hoeffding(n, c):
    E = c - 3
    return np.exp(-n * ((E**2)/18))

def empirical(n, c, theta):
    samples = get_samples(n, theta)
    sample_means = np.mean(samples, axis=1)
    return np.mean(sample_means >= c)

emp_estimates = []
markov_arr = []
chebyshev_arr = []
hoeffding_arr = []

for _n in n:
    emp_estimates.append(empirical(_n, c, theta))
    markov_arr.append(markov(c))
    chebyshev_arr.append(chebyshev(_n, c, theta))
    hoeffding_arr.append(hoeffding(_n, c))

plt.figure(figsize=(12, 6))
plt.plot(n, markov_arr, label='Markov Upper Bound')
plt.plot(n, chebyshev_arr, label='Chebyshev Upper Bound')
plt.plot(n, hoeffding_arr, label='Hoeffding Upper Bound')
plt.plot(n, emp_estimates, label='Empirically Estimated Probability')

plt.xlabel(' # of samples - n')
plt.ylabel(f'Probability P [Mn(X) ≥ {c}]')
plt.title('Comparison of Markov, Chebyshev, Hoeffding bounds with empirically estimated Probability')
plt.legend()
plt.grid(True)
plt.show()
