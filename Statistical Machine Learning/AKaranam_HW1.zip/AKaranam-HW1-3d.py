import numpy as np
import matplotlib.pyplot as plt

mean = 2
std_dev = 2

c = mean + std_dev 

sample_sz = np.arange(1, 300, 5)
emp_estimates = np.zeros(60)
chebyshev = np.zeros(60)

def chebyshev_bound(mean, std_dev, c, n):
    return std_dev**2 / (n * (c - mean)**2)

num_trials = 100  
index = 0
for n in sample_sz:
    successes = 0
    for _ in range(num_trials):
        samples = np.random.normal(mean, std_dev, n)
        Mn = np.mean(samples)
        if Mn >= c:
            successes += 1
    estimate = successes / num_trials
    emp_estimates[index] = estimate
    chebyshev[index] = chebyshev_bound(mean,std_dev,c, n)
    index+=1

plt.figure(figsize=(12, 6))
plt.plot(sample_sz, emp_estimates, label='Empirical Estimates')
plt.plot(sample_sz, chebyshev, label='Chebyshev Bound')

plt.title('Comparison of Empirical Estimates and Bounds')
plt.xlabel(' # of Samples - n')
plt.ylabel('Probability of Sample Mean >= c')
plt.legend()
plt.show()
