import numpy as np
import matplotlib.pyplot as plt

regions = np.array([-2, -1, 0, 1, 2])
cumulative_densities = [0, 0.5, 0.5, 1, 1]

plt.step(regions, cumulative_densities, where='post', label=r'$F_B(b)$')

plt.title('Plot - Rademacher')

plt.xlabel('b')
plt.ylabel(r'$F_B(b)$')

plt.legend()

plt.show()

