import numpy as np
import matplotlib.pyplot as plt

n_infinity = 3000

for k in ['Gaussian',1, 8, 64, 512]:
    if k == 'Gaussian':
        Rv_Y = np.random.randn(n_infinity)
    else:
        Rv_Y = np.sum( np.sqrt(1/ k) * np.sign(np.random.randn(n_infinity,k)), axis = 1)
    
    plt.step(sorted(Rv_Y), np.arange(1, n_infinity + 1)/float(n_infinity))


plt.legend(['Gaussian', '1', '8', '64', '512'],loc='lower right')

plt.ylim((0,1))
plt.xlim((-4,4))

plt.ylabel(r'Empirical CDF $F_Y(b)$')
plt.xlabel('Experiment Space')

plt.show()
