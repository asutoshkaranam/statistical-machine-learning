import numpy as np

mtrx_a = np.array([[1,2,3],[2,0,4],[1,2,4]])

mtrx_b_transposed = np.array([1,-2,1])

mtrx_c_transposed = np.array([1,1,1])

mtrx_b = mtrx_b_transposed.transpose()
mtrx_c = mtrx_c_transposed.transpose()

inverse_mtrx_a = np.linalg.inv(mtrx_a)
print("Inverse Matrix of A :")
print(inverse_mtrx_a)
print("Inverse Matrix of A * b :")
print(np.matmul(inverse_mtrx_a, mtrx_b))
print("A *c : ")
print(np.matmul(mtrx_a, mtrx_c))
